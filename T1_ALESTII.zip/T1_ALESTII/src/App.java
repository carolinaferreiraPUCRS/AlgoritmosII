
public class App {
    public static void main(String[] args) {
        Controller c = new Controller();
        c.execute();
    }
}
